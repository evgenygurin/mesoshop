<?php
// Text
$_['text_success']           = 'Success: Payment method has been set!';

// Error
$_['error_customer']         = 'Warning: Customer details required!';
$_['error_product']          = 'Warning: Products required!';
$_['error_shipping_address'] = 'Warning: Shipping address required!';
$_['error_shipping_method']  = 'Warning: Shipping method required!';
$_['error_payment_address']  = 'Warning: Payment address required!';
$_['error_no_payment']       = 'Warning: No payment options are available!';
$_['error_payment_method']   = 'Warning: Payment method required!';
