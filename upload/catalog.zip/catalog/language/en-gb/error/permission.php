<?php
// Text
$_['text_error'] = 'You do not have permission to access this page.';
