<?php
// Heading
$_['heading_title']   = 'Payment Methods';

// Text
$_['text_account']    = 'Account';
$_['text_no_results'] = 'You have no payment methods in your account.';
