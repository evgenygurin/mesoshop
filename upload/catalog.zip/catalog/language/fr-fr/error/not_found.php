<?php
// En-tête
$_['heading_title'] = 'La page que vous avez demandée est introuvable!';

// Texte
$_['text_error']    = 'La page que vous avez demandée est introuvable.';
