<?php
// En-tête
$_['heading_title']      = 'Vos Points de Récompenses';

// Texte
$_['text_account']       = 'Compte';
$_['text_reward']        = 'Points de Récompenses';
$_['text_total']         = 'Votre nombre total de points de récompenses est:';
$_['text_no_results']    = 'Vous n\'avez aucun point de récompenses!';

// Colonne
$_['column_date_added']  = 'Date d\'Ajout';
$_['column_description'] = 'Description';
$_['column_points']      = 'Points';
