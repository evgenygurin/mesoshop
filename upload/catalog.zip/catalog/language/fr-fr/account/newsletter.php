<?php
// En-tête
$_['heading_title']    = 'Abonnement au Bulletin';

// Texte
$_['text_account']     = 'Compte';
$_['text_newsletter']  = 'Bulletin';
$_['text_success']     = 'Succès: Votre abonnement au bulletin a été mis à jour avec succès!';

// Entrée
$_['entry_newsletter'] = 'S\'abonner';
