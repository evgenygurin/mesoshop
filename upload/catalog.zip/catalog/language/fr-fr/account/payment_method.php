<?php
// En-tête
$_['heading_title']   = 'Méthodes de Paiement';

// Texte
$_['text_account']    = 'Compte';
$_['text_no_results'] = 'Vous n\'avez aucune méthode de paiement dans votre compte.';
