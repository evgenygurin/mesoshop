<?php
// En-tête
$_['heading_title']      = 'Vos Transactions';

// Texte
$_['text_account']       = 'Compte';
$_['text_transaction']   = 'Vos Transactions';
$_['text_total']         = 'Votre solde actuel est:';
$_['text_no_results']    = 'Vous n\'avez aucune transaction!';

// Colonne
$_['column_date_added']  = 'Date d\'ajout';
$_['column_description'] = 'Description';
$_['column_amount']      = 'Montant (%s)';
