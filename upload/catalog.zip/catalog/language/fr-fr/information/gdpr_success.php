<?php
// En-tête
$_['heading_title'] = 'Succès RGPD';

// Texte
$_['text_account']  = 'Compte';
$_['text_export']   = 'Une demande d\'exportation de vos données de compte a été reçue.';
$_['text_remove']   = 'Les demandes de suppression de compte RGPD seront traitées après <strong>%s jours</strong> pour permettre le traitement des rétrofacturations, remboursements ou détections de fraude.';
