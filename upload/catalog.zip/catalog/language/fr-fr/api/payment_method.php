<?php
// Texte
$_['text_success']           = 'Succès: Le mode de paiement a été défini!';

// Erreur
$_['error_customer']         = 'Attention: Les informations du client sont requises!';
$_['error_product']          = 'Attention: Des produits sont requis!';
$_['error_shipping_address'] = 'Attention: L\'adresse d\'expédition est requise!';
$_['error_shipping_method']  = 'Attention: Le mode d\'expédition est requis!';
$_['error_payment_address']  = 'Attention: L\'adresse de paiement est requise!';
$_['error_no_payment']       = 'Attention: Aucune option de paiement n\'est disponible!';
$_['error_payment_method']   = 'Attention: Le mode de paiement est requis!';
