<?php
// Texte
$_['text_model']        = 'Modèle';
$_['text_subscription'] = 'Abonnement';
$_['text_points']       = 'Points de Récompenses';

// Colonne
$_['column_product']    = 'Produit';
$_['column_quantity']   = 'Quantité';
$_['column_price']      = 'Prix unitaire';
$_['column_total']      = 'Total';
