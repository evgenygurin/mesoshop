<?php
// En-tête
$_['heading_title'] = 'Paiement';

// Texte
$_['text_cart']     = 'Panier d\'achat';
