<?php
// Texte
$_['text_subject']  = '%s - Commission d\'affiliation';
$_['text_received'] = 'Félicitations! Vous avez reçu un paiement de commission du programme d\'affiliation %s';
$_['text_amount']   = 'Vous avez reçu:';
$_['text_total']    = 'Votre montant total de commission est maintenant:';
