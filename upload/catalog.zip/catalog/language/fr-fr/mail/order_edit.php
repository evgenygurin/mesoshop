<?php
// Texte
$_['text_subject']      = '%s - Mise à jour de la commande %s';
$_['text_order_id']     = 'ID de la commande:';
$_['text_date_added']   = 'Date d\'ajout:';
$_['text_order_status'] = 'Votre commande a été mise à jour avec le statut suivant:';
$_['text_comment']      = 'Les commentaires pour votre commande sont:';
$_['text_link']         = 'Pour consulter votre commande, cliquez sur le lien ci-dessous:';
$_['text_footer']       = 'Veuillez répondre à cet e-mail si vous avez des questions.';
