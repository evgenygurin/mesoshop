<?php
// Texte
$_['text_information']  = 'Informations';
$_['text_blog']         = 'Blog';
$_['text_service']      = 'Service client';
$_['text_extra']        = 'Extras';
$_['text_contact']      = 'Nous contacter';
$_['text_return']       = 'Retours';
$_['text_sitemap']      = 'Plan du site';
$_['text_gdpr']         = 'RGPD';
$_['text_manufacturer'] = 'Marques';
$_['text_affiliate']    = 'Affilié';
$_['text_special']      = 'Promotions';
$_['text_account']      = 'Mon compte';
$_['text_order']        = 'Historique des commandes';
$_['text_wishlist']     = 'Liste de souhaits';
$_['text_newsletter']   = 'Newsletter';
$_['text_powered']      = 'Propulsé par <a href="https://www.opencart.com">OpenCart</a><br/> %s &copy; %s';
