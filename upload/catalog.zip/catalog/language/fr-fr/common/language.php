<?php
// Texte
$_['text_language']  = 'Langue';

// Erreur
$_['error_language'] = 'Attention: Le langage n\'est pas disponible!';
