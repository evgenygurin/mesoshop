<?php
// Texte
$_['text_currency']  = 'Devise';

// Erreur
$_['error_currency'] = 'Attention: La devise n\'est pas disponible!';
