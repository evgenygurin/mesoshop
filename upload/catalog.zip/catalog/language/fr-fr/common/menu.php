<?php
// Texte
$_['text_category']  = 'Catégories';
$_['text_all']       = 'Afficher tout';
