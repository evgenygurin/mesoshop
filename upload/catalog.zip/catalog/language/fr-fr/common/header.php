<?php
// Texte
$_['text_wishlist']      = 'Liste de souhaits (%s)';
$_['text_shopping_cart'] = 'Panier d\'achat';
$_['text_account']       = 'Mon compte';
$_['text_register']      = 'S\'inscrire';
$_['text_login']         = 'Connexion';
$_['text_order']         = 'Historique des commandes';
$_['text_transaction']   = 'Transactions';
$_['text_download']      = 'Téléchargements';
$_['text_logout']        = 'Déconnexion';
$_['text_checkout']      = 'Paiement';
