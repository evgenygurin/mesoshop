<?php
// Texte
$_['text_success']    = 'Merci de nous avoir fait part de votre choix!';
$_['text_cookie']     = 'Ce site utilise des cookies. Pour plus d\'informations <a href="%s" class="alert-link modal-link">cliquez ici</a>.';

// Boutons
$_['button_agree']    = 'Oui, cela me convient!';
$_['button_disagree'] = 'Non merci!';
