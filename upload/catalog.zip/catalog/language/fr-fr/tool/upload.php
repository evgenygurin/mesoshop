<?php
// Texte
$_['text_upload']     = 'Votre fichier a été téléchargé avec succès!';

// Erreur
$_['error_token']     = 'Attention: Le jeton de réinitialisation est invalide!';
$_['error_filename']  = 'Le nom du fichier doit contenir entre 3 et 64 caractères!';
$_['error_file_type'] = 'Type de fichier invalide!';
$_['error_upload']    = 'Téléchargement requis!';
