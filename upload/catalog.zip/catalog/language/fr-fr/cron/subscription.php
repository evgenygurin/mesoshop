<?php
// Texte
$_['text_log']               = 'Vérifiez vos rapports d\'abonnements pour plus d\'informations.';

// Erreur
$_['error_store'] 		     = 'Attention: La boutique n\'a pu être trouvée!';
$_['error_language']         = 'Attention: L\'extension du mode de paiement est introuvable!';
$_['error_currency']         = 'Attention: La devise n\'a pu être trouvée!';
$_['error_customer']         = 'Attention: L\'extension du mode de paiement est introuvable!';
$_['error_payment_address']  = 'Attention: L\'extension du mode de paiement est introuvable!';
$_['error_shipping_address'] = 'Attention: L\'extension du mode de paiement est introuvable!';
$_['error_product']          = 'Attention: L\'extension du mode de paiement est introuvable!';
$_['error_option']           = 'Attention: L\'option %s n\'a pu être trouvée!';
$_['error_shipping_method']  = 'Attention: Le mode d\'expédition %s est introuvable!';
$_['error_payment_method']   = 'Attention: Le mode de paiement %s est introuvable!';
$_['error_extension']        = 'Attention: L\'extension du mode de paiement est introuvable!';
