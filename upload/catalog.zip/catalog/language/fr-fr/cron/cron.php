<?php
// Texte
$_['text_success']     = 'Succès: Vous avez exécuté la tâche cron %s!';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier les tâches cron!';
