Адаптация модуля "Mega Filter PLUS [powered by Mega Filter PRO] v1.2.9.9.7" под шаблон Moneymaker 
Ссылка на модуль: http://www.opencart.com/index.php?route=extension/extension/info&extension_id=18258&filter_search=Mega%20Filter%20PLUS

Файлы для фильтра:
Vqmod -  mega_filter_fix.xml
+ русификация (если кто лучше переведёт будем благодарны))

В админке фильтра во вкладке настройки - таб JavaScript, в поле пользовательский код JavaScript:
прописать с заменой всего того, что там прописано ниже следующее:

MegaFilter.prototype.beforeRequest = function() {
	var self = this;
};

MegaFilter.prototype.beforeRender = function( htmlResponse, htmlContent, json ) {
	var self = this;
};

MegaFilter.prototype.afterRender = function( htmlResponse, htmlContent, json ) {
	var self = this;

// Product List
    $('#list-view').click(function() {
        $('#content .pos-9 .products .product-layout > .clearfix').remove();

        $('#content .pos-9 .products .product-layout').attr('class', 'product-layout product-list');

        $('#list-view').addClass('active');
        $('#grid-view').removeClass('active');
        localStorage.setItem('display', 'list');
    });

    // Product Grid
    $('#grid-view').click(function() {
        $('#content .pos-9 .products .product-layout > .clearfix').remove();
        $('#content .pos-9 .products .product-layout').attr('class', 'product-layout product-grid');

        $('#grid-view').addClass('active');
        $('#list-view').removeClass('active');
        localStorage.setItem('display', 'grid');
    });

    if (localStorage.getItem('display') == 'list') {
        $('#list-view').trigger('click');

        $('#list-view').addClass('active');
        $('#grid-view').removeClass('active');
    } else if (localStorage.getItem('display') == 'grid') {
        $('#grid-view').trigger('click');

        $('#grid-view').addClass('active');
        $('#list-view').removeClass('active');
    }

    // don't fire tooltips on touch devices
    if(!('ontouchstart' in window)) {
        $('[data-toggle=\'tooltip\']').tooltip({container: 'body'});
        $(document).ajaxStop(function() {
            $('[data-toggle=\'tooltip\']').tooltip({container: 'body'});
        });
    }
};

function display_MFP(){};




Внимание! Настройки вывода краткого описания, атрибутов и прочей дополнительной информации в блоке товаров для этого модуля берутся с главной настройки шаблона ДЛЯ КАТАЛОГА: 
Общее > Доп. данные о товаре > Отображать наличие (Каталог)/Отображать код товара (Каталог)/Отображать короткое описание (Каталог)/Отображать атрибуты товара (Каталог)
Почему так сделано? Потому что далеко не все пользуются данным модулем, и вынесение его настроек отдельно в админку шаблона может вызвать путаницу
