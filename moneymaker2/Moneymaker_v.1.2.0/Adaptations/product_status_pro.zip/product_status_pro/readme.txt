Адаптация модуля "Статусы Товара PRO, автостатусы, стикеры 1.0 " под шаблон Moneymaker 
Ссылка на модуль: https://opencartforum.com/files/file/2163-%D1%81%D1%82%D0%B0%D1%82%D1%83%D1%81%D1%8B-%D1%82%D0%BE%D0%B2%D0%B0%D1%80%D0%B0-pro-%D0%B0%D0%B2%D1%82%D0%BE%D1%81%D1%82%D0%B0%D1%82%D1%83%D1%81%D1%8B-%D1%81%D1%82%D0%B8%D0%BA%D0%B5%D1%80%D1%8B/

ИНструкции по адаптации:
В файле catalog/view/theme/moneymaker/template/product/product/product.tpl
найти
<div class="<?php if (!$this->config->get('mmr_product_gallery_type')||$this->config->get('mmr_product_gallery_type')=='colorbox') { ?>colorbox<?php } else if ($this->config->get('mmr_product_gallery_type')=='photobox') { ?>photobox<?php } ?>">
заменить на
<div class="image <?php if (!$this->config->get('mmr_product_gallery_type')||$this->config->get('mmr_product_gallery_type')=='colorbox') { ?>colorbox<?php } else if ($this->config->get('mmr_product_gallery_type')=='photobox') { ?>photobox<?php } ?>"><?php echo $stickers?>

перед
<div class="images">
добавить вывод статусов
<?php echo $statuses; ?>

Для вывода на страницах категорий
В файле catalog/controller/product/category.php
Перед
foreach ($results as $result) {
добавить
// Product statuses module
$this->load->model('catalog/product_status');

После
foreach ($results as $result) {
добавить
$statuses = $this->model_catalog_product_status->getHTMLProductStatuses($result['product_id']);

После
$this->data['products'][] = array(
Добавить
'statuses'    => $statuses['category'],
'stickers'    => $statuses['category_stickers'],

В файле catalog/view/theme/moneymaker/template/product/category.tpl
После
<div class="image">
добавить
<?php echo $product['stickers']; ?>

После
<div class="description" itemprop="description">
добавить
<?php echo $product['statuses']; ?>

В пользовательские стили CSS добавить
.category-sticker {
z-index: 1;
}