Адаптация модуля "EC Sold Items - Number Bought" под шаблон Moneymaker 
Ссылка на модуль: http://www.opencart.com/index.php?route=extension/extension/info&extension_id=15185

После загрузки файлов адаптации и модуля, добавьте в пользовательские стили:

.ec_block_sold_items {
    color: #99CC99;
    display: inline-block;
    font-size: 20px;
    margin-left: 8px;
}