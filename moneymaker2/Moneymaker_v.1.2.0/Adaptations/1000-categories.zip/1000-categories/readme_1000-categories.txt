Адаптация модуля "1000 категорий - меню аккордеон" под шаблон Moneymaker 
Ссылка на модуль: https://opencartforum.com/files/file/684-1000-%D0%BA%D0%B0%D1%82%D0%B5%D0%B3%D0%BE%D1%80%D0%B8%D0%B9-%D0%BC%D0%B5%D0%BD%D1%8E-%D0%B0%D0%BA%D0%BA%D0%BE%D1%80%D0%B4%D0%B5%D0%BE%D0%BD/

Файлы:
Vqmod с изменениями в tpl-файл шаблона модуля и в контроллер модуля для улучшения визуального отображения категорий

Инструкция по адаптации:
Адаптация расчитана на работу с последней версией модуля, из архива 1000-categories.zip.
Достаточно скопировать все содержимое папки с адаптацией в соответствующий каталог на вашем сервере

После этого, следует добавить в пользовательские стили шаблона в его настройках следующий код:

/*1000-categories adaptation*/
.box .box-content > .box-category > li > ul > li {
  padding-bottom: 3px;
  padding-top: 3px;
}
.box .box-content > .box-category > li > ul > li > ul > li {
  font-size: 85%;
  padding-bottom: 3px;
  padding-left: 10px;
}
.box .box-content > .box-category > li > ul > li > ul > li::before {
  content: "- ";
}
