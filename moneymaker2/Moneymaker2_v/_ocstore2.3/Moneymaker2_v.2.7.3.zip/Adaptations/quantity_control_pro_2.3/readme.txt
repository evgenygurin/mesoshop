Адаптация модуля Выбор количества товара на любой странице PRO для OpenCart и ocStore 2.3 к шаблону Moneymaker 2
Ссылка на модуль https://opencartforum.com/files/file/2778-vybor-kolichestva-tovara-na-lyuboy-stranice-pro-dlya-opencart-i-ocstore-2/
Загрузите содержимое папки upload в корень сайта в соответствии со структурой каталогов, после чего установите модификатор адаптации quantity_control_PRO_for_OC_v2.1.ocmod.xml (устанавливать оригинальные файлы модуля не нужно, т.к. адаптация включает их функциональность), затем обновите кеш модификаторов
