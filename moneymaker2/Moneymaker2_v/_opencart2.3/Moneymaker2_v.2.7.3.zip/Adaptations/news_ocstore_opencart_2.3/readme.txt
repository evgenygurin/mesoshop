Адаптация модуля "Новости для Opencart 2.x 1.1.3" под шаблон Moneymaker 2 (Opencart 2.3)
Ссылка на модуль: https://opencartforum.com/files/file/3027-%D0%BD%D0%BE%D0%B2%D0%BE%D1%81%D1%82%D0%B8-%D0%B4%D0%BB%D1%8F-opencart-2x/

Инструкция: загрузите файлы адаптации согласно их расположению на свой сайт